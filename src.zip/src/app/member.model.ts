
export class member {
    id: number = 0;
    firstName: string = "";
    lastName: string = "";
    jobTitle: string = "";
    team: string = "";
    status: string = "";
}

export class team{
      id : number = 0;
      teamName : string = "";
}